<?php

/**
 *
 * This is your standard WordPress
 * functions.php file.
 *
 * @author  Alessandro Vellutini
 *
*/

require_once get_template_directory() . '/core/main.php';

?>