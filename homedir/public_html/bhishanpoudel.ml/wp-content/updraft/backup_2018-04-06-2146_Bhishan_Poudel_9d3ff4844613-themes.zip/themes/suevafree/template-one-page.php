<?php

	/*
	Template Name: One Page
	*/

	get_header('one-page');
	do_action( 'suevafree_onepage_sidebar', 'onepage-sidebar-area');
	get_footer(); 
	
?>