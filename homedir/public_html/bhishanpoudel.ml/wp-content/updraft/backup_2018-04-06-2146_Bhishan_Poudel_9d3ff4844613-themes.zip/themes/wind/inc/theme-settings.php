<?php
/**
 * Wind Theme Settings
 * 
 * @package	wind
 * @since   1.0
 * @author  RewindCreation
 * @license GPL v3 or later
 * @link    http://www.rewindcreation.com/
 */

define( 'WIND_VERSION', '1.1.5' );
define( 'WIND_THEME_ID', 'wind' );
define( 'WIND_THEME_NAME', 'Wind' );
define( 'WIND_FRAMEWORK', 'foundation' );
