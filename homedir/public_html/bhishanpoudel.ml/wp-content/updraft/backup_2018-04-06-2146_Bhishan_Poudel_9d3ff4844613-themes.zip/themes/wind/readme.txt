Thanks for choosing Wind WordPress Theme.
--------------------------------------------------------------------------
 Documentation :
--------------------------------------------------------------------------
For documentations and user guides, 
visit http://www.rewindcreation.com/docs
--------------------------------------------------------------------------
For support, 
visit http://www.rewindcreation.com/support
--------------------------------------------------------------------------
Theme Options
--------------------------------------------------------------------------
We provide two way to customize your site. On your WordPress Dashboard

Appearance > Theme Options

and 

Appearance > Customize

--------------------------------------------------------------------------
 Licenses:
--------------------------------------------------------------------------
Wind WordPress Theme, Copyright 2014 Stephen Cui
Wind is distributed under the terms of the GNU GPL v3

The resources used in Wind are all GPL-compatible:

Foundation Framework: Licensed under MIT Open Source
http://foundation.zurb.com/

Font Awesome is licensed under SIL Open Font License for font 
	 and MIT for CSS.
http://fortawesome.github.com/Font-Awesome/

bxSlider is licensed under WTFPL license. 
http://bxslider.com/

Bootstrap (Buttons) is licensed under MIT
http://getbootstrap.com

Theme Backend, other icons and images are created by RewindCreation
and licensed under GPL v3
http://www.rewindcreation.com/
--------------------------------------------------------------------------
Screenshot Images
--------------------------------------------------------------------------
All images used on screenshot is owned by Theme Author and
released under GPL.
