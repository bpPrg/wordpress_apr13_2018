=== NuvioAxis Green ===

CeskaLipa is a redesigned version of the default theme Twenty Fourteen.

== Copyright ==  
CeskaLipa is distributed under the terms of the GNU General Public License v2 or later.  

CeskaLipa is a derivative of the Twenty Fourteen theme by the WordPress Development Team:  
http://wordpress.org/themes/twentyfourteen
Copyright: Automattic, automattic.com
Licensed under GPLv2 or later

Functions, definitions, scripts, fonts are under GNU General Public License v2 or later and are taken over 
  from Twenty Fourteen theme.
  
Default background (blue modern city) was downloaded from 
  http://www.freepik.com/free-vector/blue-modern-city-vector-illustration_596057.htm

Twenty Fourteen and CeskaLipa are under GNU General Public License v2 or later 
  (for more about GPL visit http://www.gnu.org/licenses/gpl-2.0.html).