jQuery( document ).ready(function() {

	/* Masonry */
	var $container = jQuery('#content');
	$container.masonry({
		itemSelector: 'article'
	});
	
});	