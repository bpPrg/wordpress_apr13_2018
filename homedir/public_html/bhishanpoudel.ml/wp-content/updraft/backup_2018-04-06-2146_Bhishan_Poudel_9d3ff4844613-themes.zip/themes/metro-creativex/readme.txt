= Metro CreativeX =
Contributors: codeinwp.com
Tags: gray, dark, white, black, purple, red, green, yellow, blue, two-columns,responsive-layout, fluid-layout, custom-menu, custom-header, custom-background, editor-style, featured-images, threaded-comments, translation-ready, post-formats
Requires at least:	3.3.0
Tested up to:		4.0
Metro CreativeX
== Description ==
Metro CreativeX is a free metro WordPress theme, super clean and fully responsive design. Coded with care in HTML5 &amp; CSS3, is easy to customize and well documented.<a href="http://themeisle.com/forums/forum/metrox/">Official support forum</a> (http://themeisle.com/forums/forum/metrox/)
= License =

Metro CreativeX  theme, Copyright (C) 2013 codeinwp.com
Metro CreativeX  theme is licensed under the GPL3.

Unless otherwise specified, all the theme files, scripts and images are licensed under GNU General Public License v3.
The exceptions to this license are as follows:


jquery.carouFredSel-6.1.0.js
License: Dual licensed under the MIT and GPL licenses.
Copyright: Copyright (c) 2012 Fred Heusschen - www.frebsite.nl

Icons:
License:  GNU General Public License v3
Copyright:  2014 www.themeisle.com

Images from screenshot and from Metro CustomizR page are from https://unsplash.com/ distributed under GNU General Public License v3.

The image from Metro CustomizR page is from https://unsplash.com/photos/M0HwJ4j58-w/ distributed under GNU General Public License v3.

Images from Metro CustomizR page are from https://pixabay.com/ distributed under CC0 Public Domain.
images/individual.png : https://pixabay.com/en/seychelles-flag-fingerprint-country-662481/
images/document.png : https://pixabay.com/en/document-layout-template-design-24951/
images/fonts.jpg : https://pixabay.com/en/word-cloud-words-tag-cloud-679936/
images/palette.png : https://pixabay.com/en/palette-circle-round-wheel-colour-42290/